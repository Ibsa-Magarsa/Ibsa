
// Name and id number of group members
// 1. Naol Gelana -------- UGR/35081/16
// 2. Ibsa Magarsa ------- UGR/34652/16
// 3. Dagim Girma -------- UGR/34169/16
// 4. Roba Rikita -------- UGR/35275/16
// 5. Amanuel Geremu ----- UGR/33905/16


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import bank.SavingsAccount;

public class BankSystemGUI extends JFrame {
    private JTextField accNumberField, nameField, amountField;
    private JTextArea infoArea;
    private JButton loginBtn, createBtn, depositBtn, withdrawBtn, displayBtn, displayFileBtn;

    private SavingsAccount currentAccount;
    private static final String FILE_NAME = "accounts.txt";

    public BankSystemGUI() {
        setTitle("Bank System");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new GridLayout(4, 2));
        accNumberField = new JTextField();
        nameField = new JTextField();
        amountField = new JTextField();

        topPanel.add(new JLabel("Account Number:"));
        topPanel.add(accNumberField);
        topPanel.add(new JLabel("Holder Name (for new account):"));
        topPanel.add(nameField);
        topPanel.add(new JLabel("Amount:"));
        topPanel.add(amountField);

        loginBtn = new JButton("Login");
        createBtn = new JButton("Create Account");
        depositBtn = new JButton("Deposit");
        withdrawBtn = new JButton("Withdraw");
        displayBtn = new JButton("Display Info");
        displayFileBtn = new JButton("Display All Accounts");

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(loginBtn);
        buttonPanel.add(createBtn);
        buttonPanel.add(depositBtn);
        buttonPanel.add(withdrawBtn);
        buttonPanel.add(displayBtn);
        buttonPanel.add(displayFileBtn);

        infoArea = new JTextArea();
        infoArea.setEditable(false);

        add(topPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
        add(new JScrollPane(infoArea), BorderLayout.SOUTH);

        loginBtn.addActionListener(e -> loginAccount());
        createBtn.addActionListener(e -> createAccount());
        depositBtn.addActionListener(e -> deposit());
        withdrawBtn.addActionListener(e -> withdraw());
        displayBtn.addActionListener(e -> displayInfo());
        displayFileBtn.addActionListener(e -> displayAllAccounts());
    }

    private void loginAccount() {
        String accNo = accNumberField.getText().trim();
        currentAccount = findAccountByNumber(accNo);
        if (currentAccount != null) {
            infoArea.setText("Account loaded successfully.\n");
            displayInfo();
        } else {
            infoArea.setText("Account not found.\n");
        }
    }

    private void createAccount() {
        String accNo = accNumberField.getText().trim();
        String name = nameField.getText().trim();
        try {
            double balance = Double.parseDouble(amountField.getText().trim());
            currentAccount = new SavingsAccount(accNo, name, balance);
            saveAccountToFile(currentAccount);
            infoArea.setText("Account created and saved.\n");
            displayInfo();
        } catch (NumberFormatException e) {
            infoArea.setText("Invalid balance amount.\n");
        }
    }

    private void deposit() {
        if (currentAccount != null) {
            try {
                double amt = Double.parseDouble(amountField.getText().trim());
                currentAccount.deposit(amt);
                infoArea.setText("Deposited successfully.\n");
                displayInfo();
            } catch (NumberFormatException e) {
                infoArea.setText("Invalid deposit amount.\n");
            }
        }
    }

    private void withdraw() {
        if (currentAccount != null) {
            try {
                double amt = Double.parseDouble(amountField.getText().trim());
                if (amt <= currentAccount.getBalance()) {
                    currentAccount.withdraw(amt);
                    infoArea.setText("Withdrawn successfully.\n");
                } else {
                    infoArea.setText("Insufficient balance!\n");
                }
                displayInfo();
            } catch (NumberFormatException e) {
                infoArea.setText("Invalid withdrawal amount.\n");
            }
        }
    }

    private void displayInfo() {
        if (currentAccount != null) {
            infoArea.append("\nAccount Number: " + currentAccount.getAccountNumber());
            infoArea.append("\nHolder Name: " + currentAccount.getAccountHolderName());
            infoArea.append("\nBalance: " + currentAccount.getBalance());
            infoArea.append("\n------------------------------\n");
        }
    }

    private void displayAllAccounts() {
        infoArea.setText("All Accounts:\n");
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    infoArea.append("Account Number: " + parts[0] +
                                     " | Holder Name: " + parts[1] +
                                     " | Balance: " + parts[2] + "\n");
                }
            }
        } catch (IOException e) {
            infoArea.setText("Error reading accounts: " + e.getMessage());
        }
    }

    private void saveAccountToFile(SavingsAccount account) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME, true))) {
            writer.write(account.getAccountNumber() + "," + account.getAccountHolderName() + "," + account.getBalance());
            writer.newLine();
        } catch (IOException e) {
            infoArea.setText("Error saving account: " + e.getMessage());
        }
    }

    private SavingsAccount findAccountByNumber(String accNo) {
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3 && parts[0].equals(accNo)) {
                    return new SavingsAccount(parts[0], parts[1], Double.parseDouble(parts[2]));
                }
            }
        } catch (IOException e) {
            infoArea.setText("File error: " + e.getMessage());
        }
        return null;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new BankSystemGUI().setVisible(true));
    }
}
